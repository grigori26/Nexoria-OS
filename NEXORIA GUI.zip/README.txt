EN.... 
The Nexora OS operating system is written in Python; this is the gui (graphics) version.

PL... To jest Nexora OS system operacyjny napisany w pythonie to jest wersja gui (graficzna).
